%largest eigen value done
%
fID = fopen('eigen.txt', 'rt');
sizen = 1;
n = fscanf(fID, '%f', sizen);
        
sizeA0 = [n n];
A0 = fscanf(fID, '%f', sizeA0);
A = A0';
disp(A);
tol = fscanf(fID, '%f', sizen);

prompt = 'What do you want?\nL.Largest eigenvalue\nA.All E\eigenvalues\n';
t = input(prompt, 's');
if strcmp(t, 'L')
    maxIter = input('What should be the maximum iteration number the program should run: ');
    y = [1 0 0 ];
    z = zeros;
    y = y';
    for i = 1: maxIter
        z = A*y;
        ep1 = dot(y,z);
        y = z/norm(z);
        z = A*y;
        ep2 = dot(y,z);
        err = abs((ep2 - ep1)/ep2);
        if err < tol
            break;
        end
    end
    disp(z);
    disp(ep2);
    fileID = fopen('eigen1_out.txt','w');
    fprintf(fileID,'Direct Power Method:\n\n');
    fprintf(fileID,'Eigenvalue is:\n');
    fprintf(fileID,'%f\n\n', ep2);
    fprintf(fileID,'Eigenvector is:\n');
    for i = 1: n
        fprintf(fileID,'%f    ', z(i));
    end
    fprintf(fileID,'\n\nIterations:\n');
    fprintf(fileID,'%f\n', maxIter);
    fclose(fileID);
end
if strcmp(t, 'A')
    maxIter = input('What should be the maximum iteration number the program should run: ');
    ep1 = zeros;
    err = zeros;
    ep2 = zeros;
    for p = 1: maxIter 
        x = num2cell(A,1);
        y = zeros(n,n);
        y = num2cell(y,1);
        z = zeros(n,n);
        z = num2cell(z,1);
        for i = 1: n
            ep1(i) = A(i,i);
        end
        for i = 1: n
            sum = 0;
            for k = 1: i
                sum = sum + (dot(x{i},y{k}))*y{k};
            end
            z{i} = x{i} - sum;
            y{i} = z{i}/norm(z{i});
        end
        Q = cell2mat(y);
        R = zeros(n,n);
        for i = 1: n
            for j = 1: n
                R(i,j) = dot(y{i},x{j});
            end
        end
        A = R*Q;
        for i = 1: n
            ep2(i) = R(i,i);
        end
        for i = 1: n
            err(i) = abs((ep2(i) - ep1(i))/ep1(i))*100;
        end
        Err = max(err);
        if Err < tol
            break;
        end
    end
    disp(ep2);
    fileID = fopen('eigen2_out.txt','w');
    fprintf(fileID,'QR Method:\n\n');
    fprintf(fileID,'Eigenvalues are:\n');
    for i = 1: n
        fprintf(fileID,'%f    ', ep2(i));
    end
    fprintf(fileID,'\n\nIterations:\n');
    fprintf(fileID,'%f\n', maxIter);
    fclose(fileID);
end