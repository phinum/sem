% thomas done
% Gauss Elimination done 
% inverse by GJA done
% Cholesky done
% LUD done
% full pivoting for LUD done
% full pivoting for cholesky remains
prompt = 'What would you like to do?\nA.Solve the system of equation.\nB.Perform an LU Decomposition.\nC.Perform a Matrix Inversion.\n';
t = input(prompt,'s');
if strcmp(t, 'A')
    prompt = 'Is the system is tridiagonal?: ';
    reply = input(prompt, 's');
    if strcmp(reply, 'Y')
        fID = fopen('thomas.txt', 'rt');
        sizen = 1;
        n = fscanf(fID, '%f', sizen);
        
        sized = n;
        d = fscanf(fID, '%f', sized);
        
        sizeb = n;
        b = fscanf(fID, '%f', sizeb);
        
        sizeu = n;
        u = fscanf(fID, '%f', sizeu);
      
        sizel = n;
        l = fscanf(fID, '%f', sizel);
        fclose(fID);

        p(1) = d(1);
        q(1) = b(1);
        for i = 2: n
            p(i) = d(i) - (l(i)/p(i - 1))*u(i-1);
            q(i) = b(i) - (l(i)/p(i - 1))*q(i-1);
        end
        x = zeros;
        x(n) = q(n)/p(n);
        for i = (n - 1): -1: 1
            x(i) = (q(i) - u(i)*x(i+1))/p(i);
        end
        disp(x);
        fileID = fopen('thomas_out.txt','w');
        fprintf(fileID,'%f\n', x);
        fclose(fileID);
    end
    
    % Gauss Elimination by Partial pivoting
    if strcmp(reply, 'N')
        fID = fopen('GEpp.txt', 'rt');
        sizen = 1;
        n = fscanf(fID, '%f', sizen);
        
        sizeA0 = [n n];
        A0 = fscanf(fID, '%f', sizeA0);
        
        sizeb = n;
        b = fscanf(fID, '%f', sizeb);
        fclose(fID);
        A0 = A0';
        A = [A0 b];
        disp(A);
        [n,n0] = size(A);
        x = zeros;
        for i = 1: n-1
            for j = i + 1: n
                if abs(A(j,i)) > abs(A(i,i))
                    T = A(j,:); 
                    A(j,:) = A(i,:);
                    A(i,:) = T;
                end  
            end    
        end 
        disp(A);
        for k = 1: n - 1
            for i = k + 1: n
                l = A(i,k)/A(k,k);
                for j = k: n + 1
                    A(i,j) = A(i,j) - l*A(k,j);
                end
            end
        end
        disp(A);
        x(n) = A(n,n+1)/A(n,n);
        for j = n - 1: -1: 1
            ext = 0;
            for i = 1: n - j
                ext = ext + A(j,n + 1 - i)*x(n + 1 - i);
            end
            x(j) = (A(j,n + 1) - ext)/A(j,j);
        end 
        disp(x);    
        fileID = fopen('GEpp_out.txt','w');
        fprintf(fileID,'%f\n', x);
        fclose(fileID);
    end
end


if strcmp(t,'B') 
    prompt = 'Is the matrix is symmetric and positive definite?: ';
    reply = input(prompt, 's');
    
    %Cholesky LU Decomposition
    if strcmp(reply, 'Y')
        fID = fopen('Cholesky.txt', 'rt');
        sizen = 1;
        n = fscanf(fID, '%f', sizen);
        
        sizeA = [n n];
        A = fscanf(fID, '%f', sizeA);
        
        sizeb = n;
        b = fscanf(fID, '%f', sizeb);
        fclose(fID);
        A = A';
        l = zeros(n,n);
        disp(A);
        r = zeros;
        c = zeros;
        for i = 1: n - 1
            row = i;
            col = i;
            m = abs(A(i,i));
            for j = i: n
                if abs(A(j,j)) > m
                    m = A(j,j);
                    row = j;
                    col = j;
                end
            end
            r = A(row, :);
            A(row, :) = A(i, :);
            A(i, :) = r;
            c = A(:, col);
            A(:, col) = A(:, i);
            A(:, i) = c;
        end
        disp(A);
        for k = 1: n
            for j = 1: n
                if j == k
                    sum = 0;
                    for p = 1: k - 1
                        sum = sum + l(k,p)^2;
                    end    
                    l(j,j) = (A(j,j) - sum)^(1/2);
                end
                if j < k
                    sum = 0;
                    for p = 1: k - 1
                        sum = sum + l(k,p)*l(j,p);
                    end
                    l(k,j) = (A(k,j) - sum)/l(j,j);
                end
                if j > k
                    l(k,j) = 0;
                end
            end
        end
        disp(l);
        fileID = fopen('Cholesky_out.txt','w');
        for i = 1: n - 1
            fprintf(fileID,'row %d is changed with row %d.\n', row, i);
            fprintf(fileID,'column %d is changed with column %d.\n\n', col, i);
        end
        for i = 1: n
            for j = 1: n
               fprintf(fileID,'%f    ', l(i,j));
            end
            fprintf(fileID,'\n');
        end
        fclose(fileID);
    end
    
    %LUD
    if strcmp(reply, 'N')
        fID = fopen('LUD.txt', 'rt');
        sizen = 1;
        n = fscanf(fID, '%f', sizen);

        sizeA = [n n];
        A = fscanf(fID, '%f', sizeA);

        sizeb = n;
        b = fscanf(fID, '%f', sizeb);
        fclose(fID);
        A = A';
        disp(A);
        L = zeros(n,n);
        U = zeros(n,n);
        r = zeros;
        c = zeros;
        prompt = 'By what method?\nA. Doolittle\nB. Crout\n';
        reply = input(prompt, 's');
        
        %Doolittle
        if strcmp(reply, 'A')
            for i = 1: n - 1
                [maxc, ri] = max(abs(A(i:n, i:n)));
                [maxm, cj] = max(maxc);
                row = ri(cj) + (i-1); 
                col = cj + (i - 1);
                A([i, row], :) = A([row, i], :);
                A(:, [i, col]) = A(:, [col, i]);
                r(i) = row;
                c(i) = col;
                if A(i,i) == 0
                  break
                end
            end
            disp(A);
            for i = 1: n
                L(i,i) = 1;
            end
            for i = 1: n
                for j = 1: n
                    if j > i
                        L(i,j) = 0;
                    end
                    if j >= i
                        sum = 0;
                        for k = 1: i - 1
                            sum = sum + L(i,k)*U(k,j);
                        end
                        U(i,j) = A(i,j) - sum;
                    end
                    if j < i
                        U(i,j) = 0;
                        sum = 0;
                        for k = 1: j - 1
                            sum = sum + L(i,k)*U(k,j);
                        end
                        L(i,j) = (A(i,j) - sum)/U(j,j);
                    end
                end
            end
            disp(L);
            disp(U);
            fileID = fopen('LUDd_out.txt','w');
            for i = 1: n - 1
                fprintf(fileID,'row %d is changed with row %d.\n', row, i);
                fprintf(fileID,'column %d is changed with column %d.\n\n', col, i);
            end
            fprintf(fileID,'\nL matrix of the given A matrix by Doolittle decomposition is :\n\n');
            for i = 1: n
                for j = 1: n
                   fprintf(fileID,'%f    ', L(i,j));
                end
                fprintf(fileID,'\n');
            end
            fprintf(fileID,'\nU matrix of the given A matrix by Doolittle decomposition is :\n\n');
            for i = 1: n
                for j = 1: n
                   fprintf(fileID,'%f    ', U(i,j));
                end
                fprintf(fileID,'\n');
            end
            fclose(fileID);
        end
        
        %Crout
        if strcmp(reply, 'B')
            for i = 1: n - 1
                [maxc, ri] = max(abs(A(i:n, i:n)));
                [maxm, cj] = max(maxc);
                row = ri(cj) + (i-1); 
                col = cj + (i - 1);
                r(i) = row;
                c(i) = col;
                A([i, row], :) = A([row, i], :);
                A(:, [i, col]) = A(:, [col, i]);
                if A(i,i) == 0
                  break
                end
            end
            disp(A);
            for i = 1: n
                U(i,i) = 1;
            end
            for i = 1: n
                for j = 1: n
                    if j > i
                        L(i,j) = 0;
                        sum = 0;
                        for k = 1: i - 1
                            sum = sum + L(i,k)*U(k,j);
                        end
                        U(i,j) = (A(i,j) - sum)/L(i,i);
                    end
                    if j <= i
                        sum = 0;
                        for k = 1: j - 1
                            sum = sum + L(i,k)*U(k,j);
                        end
                        L(i,j) = (A(i,j) - sum);
                    end
                    if j < i
                        U(i,j) = 0;
                    end
                end
            end
            disp(L);
            disp(U);
            fileID = fopen('LUDc_out.txt','w');
            for i = 1: n - 1
                fprintf(fileID,'row %d is changed with row %d.\n', row, i);
                fprintf(fileID,'column %d is changed with column %d.\n\n', col, i);
            end
            fprintf(fileID,'\nL matrix of the given A matrix by Crouts decomposition is :\n\n');
            for i = 1: n
                for j = 1: n
                   fprintf(fileID,'%f    ', L(i,j));
                end
                fprintf(fileID,'\n');
            end
            fprintf(fileID,'\nU matrix of the given A matrix by Crouts decomposition is :\n\n');
            for i = 1: n
                for j = 1: n
                   fprintf(fileID,'%f    ', U(i,j));
                end
                fprintf(fileID,'\n');
            end
            fclose(fileID);
        end
    end
end

%Gauss Jordan Elimination
if strcmp(t,'C') 
    fID = fopen('GJA_inverse.txt', 'rt');
    sizen = 1;
    n = fscanf(fID, '%f', sizen);
    
    sizeA0 = [n n];
    A0 = fscanf(fID, '%f', sizeA0);
    fclose(fID);

    A0 = A0';
    I = eye(n);
    B = eye(n);
    A = [A0 I];
    disp(A);
    
    for j = 1: n - 1
        for i = j + 1: n
            A(i,:) = A(i,:) - A(j,:)*(A(i,j)/A(j,j));
        end
    end
    for j = n: -1: 2
        for i = j - 1: -1: 1
            A(i,:) = A(i,:) - A(j,:)*(A(i,j)/A(j,j));
        end
    end
    for k = 1: n
        A(k,:) = A(k,:)/A(k,k);
    end
    j = 1;
    for i = (n + 1): (2*n)
        B(:,j) = A(:,i);
        j = j + 1;
    end
    disp(B);
    fileID = fopen('GJA_inverse_out.txt','w');
    fprintf(fileID,'Inverse of the given matrix by Gauss Jordan Elimination is :\n\n');
    for i = 1: n
        for j = 1: n
            fprintf(fileID,'%f    ', B(i,j));
        end
        fprintf(fileID,'\n');
    end
    fclose(fileID);
end