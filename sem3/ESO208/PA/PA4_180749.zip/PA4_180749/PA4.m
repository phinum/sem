prompt = 'What would you like to do?\nA.Question A\nB.Question B\n';
t = input(prompt,'s');
if strcmp(t, 'A')
    fileId = fopen('input.txt','rt');
    func = fscanf(fileId,'%s',1);
    x0 = fscanf(fileId,'%f',1);
    y0 = fscanf(fileId,'%f',1);
    xf = fscanf(fileId,'%f',1);
    h = fscanf(fileId,'%f',1);
    fx = matlabFunction(str2sym(func));
    prompt = 'How would you do it?\nA.Euler Forward\nB.Euler Backward\nC.Trapezoial\nD.4th-order Adams Bashforth\nE.4th order Adams Moultan\nF.4th order BDF\nG.4th order Runge Kutta';
    a = input(prompt,'s');
    % Euler forward
    if strcmp(a, 'A')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
             x(i) = x(i-1)+h;
        end
        y(1) = y0;
        for i =2:(n+1)
            y(i) = y(i-1)+h*feval(fx,x(i-1),y(i-1));
        end 
    end
    % Euler backward
    if strcmp(a, 'B')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
             x(i) = x(i-1)+h;
        end
        y(1) = y0;
        for i =2:(n+1)
            y(i) = y(i-1)+h*feval(fx,x(i-1),y(i-1));
            y(i) = y(i-1)+h*feval(fx,x(i),y(i));
        end
    end
    % Trapezoial
    if strcmp(a, 'C')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
            x(i) = x(i-1)+h;
        end
        y(1) = y0;
        for i =2:(n+1)
            y(i) = y(i-1)+h*feval(fx,x(i-1),y(i-1));
            y(i) = y(i-1)+h*0.5*(feval(fx,x(i),y(i))+feval(fx,x(i-1),y(i-1)));
        end
    end
    % 4th-order Adams Bashforth
    if strcmp(a, 'D')
       n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
            x(i) = x(i-1)+h;
        end
        y(1) = y0;
        y(2) = y(1)+ h*feval(fx,x(1),y(1));
        y(3) = y(2)+ h*1.5*feval(fx,x(2),y(2))-0.5*h*feval(fx,x(1),y(1));
        y(4) = y(3)+ h*1.97*feval(fx,x(3),y(3))-h*1.34*feval(fx,x(2),y(2))+h*0.42*feval(fx,x(1),y(1));

        for i=5:(n+1)
            y(i) = y(i-1)+ h*((55/24)*feval(fx,x(i-1),y(i-1))-(59/24)*feval(fx,x(i-2),y(i-2))+(37/24)*feval(fx,x(i-3),y(i-3))-(9/24)*feval(fx,x(i-4),y(i-4)));
        end 
    end
    % 4th order Adams Moultan
    if strcmp(a, 'E')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
            x(i) = x(i-1)+h;
        end
        y(1) = y0; 
        %euler backward for first value
        y(2) = y(1)+h*feval(fx,x(1),y(1));
        y(2) = y(1)+h*feval(fx,x(2),y(2));
        % trapezoidal for second value 
        y(3) = y(2)+ h*1.5*feval(fx,x(2),y(2))-0.5*h*feval(fx,x(1),y(1));
        y(3) = y(2)+ h*0.5*(feval(fx,x(2),y(2)) + feval(fx,x(3),y(3)));
        % 3rd order ADM for third value
        y(4) = y(3)+ h*1.97*feval(fx,x(3),y(3))-h*1.34*feval(fx,x(2),y(2))+h*0.42*feval(fx,x(1),y(1)); 
        y(4) = y(3) +h*((5/12)*feval(fx,x(4),y(4)) + (2/3)*feval(fx,x(3),y(3))-(1/12)*feval(fx,x(2),y(2)));
        for i=5:(n+1)
           y(i) = y(i-1)+ h*((55/24)*feval(fx,x(i-1),y(i-1))-(59/24)*feval(fx,x(i-2),y(i-2))+(37/24)*feval(fx,x(i-3),y(i-3))-(9/24)*feval(fx,x(i-4),y(i-4)));
           y(i) = y(i-1)+ h*((3/8)*feval(fx,x(i),y(i)) + (19/24)*feval(fx,x(i-1),y(i-1))- (5/24)*feval(fx,x(i-2),y(i-2)) +(1/24)*feval(fx,x(i-3),y(i-3)));
        end
    end
    % 4th order BDF
    if strcmp(a, 'F')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
            x(i) = x(i-1)+h;
        end
        y(1) = y0; 
        %euler backward for first value
        y(2) = y(1)+h*feval(fx,x(1),y(1)); 
        y(2) = y(1)+h*feval(fx,x(2),y(2));
        % trapezoidal for second value
        y(3) = y(2)+ h*1.5*feval(fx,x(2),y(2))-0.5*h*feval(fx,x(1),y(1));
        y(3) = y(2)+ h*0.5*(feval(fx,x(2),y(2)) + feval(fx,x(3),y(3)));
        % 3rd order ADM for third value 
        y(4) = y(3)+ h*1.97*feval(fx,x(3),y(3))-h*1.34*feval(fx,x(2),y(2))+h*0.42*feval(fx,x(1),y(1)); 
        y(4) = y(3) +h*((5/12)*feval(fx,x(4),y(4)) + (2/3)*feval(fx,x(3),y(3))-(1/12)*feval(fx,x(2),y(2)));
        for i=5:(n+1)
            y(i) = y(i-1)+ h*((55/24)*feval(fx,x(i-1),y(i-1))-(59/24)*feval(fx,x(i-2),y(i-2))+(37/24)*feval(fx,x(i-3),y(i-3))-(9/24)*feval(fx,x(i-4),y(i-4)));
            y(i) = (12/25) *(4*y(i-1) - 3*y(i-2) +(4/3)*y(i-3) - 0.25*y(i-4) +h*feval(fx,x(i),y(i)));
        end
    end
    % 4th order Runge Kutta
    if strcmp(a, 'G')
        n = (xf-x0)/h;
        x = zeros(n+1,1);
        y = zeros(n+1,1);
        x(1) = x0;
        for i=2:(n+1)
            x(i) = x(i-1)+h;
        end
        y(1) = y0;
        for i=2:(n+1)
            fi0 = feval(fx,x(i-1),y(i-1));
            fi1 = feval(fx,(x(i-1)+h/2),(y(i-1)+0.5*h*fi0));
            fi2 = feval(fx,(x(i-1)+h/2),(y(i-1)+0.5*h*fi1));
            fi3 = feval(fx,(x(i-1)+h),(y(i-1)+h*fi2));
            y(i) = y(i-1) + h*((1/6)*fi0 +(1/3)*(fi1+fi2) + (1/6)*fi3);
        end
    end
    out = input('Name of Output File: ','s');
    fout = fopen(out,'w');
    fprintf(fout,'%s\n','x');
    fprintf(fout,'%f ',x);
    fprintf(fout,'\n');
    fprintf(fout,'%s\n','y');
    fprintf(fout,'%f ',y);
    fclose(fout);

    figure (1)
    scatter (x,y)
    title('Plot of X and Y');
    xlabel('x');
    ylabel('y');
    xlim([x0 xf]);
end

if strcmp(t, 'B')
    h=input('What is delta x?\n');
    y=input('What method so you want?\n1.Backward Difference\n2.Central Difference using Ghost node\n');

    if y==1
        backward(h);
    elseif y==2
        central(h);
    end
end

function [y] = backward(h)

    x=0:h:2;
    [r c]=size(x);
    A=zeros(c-2);
    B=zeros(c-2,1);
    [A,B,l]= matrix(h,c,x,A,B);
    i=l-2;
    p=1;
    q=-(x(i+1)+3)/(x(i+1)+1);
    r=(x(i+1)+3)/((x(i+1)+1)*(x(i+1)+1));
    s=2*(x(i+1)+1)+3*r;
    a=p/(h*h)-q/(2*h);
    b=-2*p/(h*h)+r;
    g=p/(h*h) + q/(2*h);
    A(i,i-1) = a-g/3;
    A(i,i)=b+4*g/3;
    B(i,1)=s;
    mat=[];
    mat(1,1)=0;
    mat(c-2,3)=0;
    for i=1:c-2
      if i==1
          mat(i,2)=A(i,i);
          mat(i,3)=A(i,i+1);
          mat(i,4)=B(i,1);
      elseif i<=c-3
          mat(i,1)=A(i,i-1);
          mat(i,2)=A(i,i);
          mat(i,3)=A(i,i+1);
          mat(i,4)=B(i,1);
      elseif i==c-2
         mat(i,1)= A(i,i-1);
         mat(i,2)=A(i,i);
         mat(i,4)=B(i,1);
      end
    end
    
    y=[];
    x=x(1:l);
    [y]=thomas(mat)
    z = (4*y(1,l-2) - y(1,l-3))/3
    y=[5 y z];
    x
    y

    out = input('Name of Output File: ','s');
    fout = fopen(out,'w');
    fprintf(fout,'%s\n','x');
    fprintf(fout,'%f ',x);
    fprintf(fout,'\n');
    fprintf(fout,'%s\n','y');
    fprintf(fout,'%f ',y);

    fclose(fout);

    y=y';
    scatter(x,y,'filled');
end
    

 function [y]= central(h)

    x=0:h:2;
    [r c]=size(x);
    A=zeros(c-1);
    B=zeros(c-1,1);
    [A,B,l]= matrix(h,c,x,A,B);

    i=c-2;
    p=1;
    q=-(x(i+1)+3)/(x(i+1)+1);
    r=(x(i+1)+3)/((x(i+1)+1)*(x(i+1)+1));
    s=2*(x(i+1)+1)+3*r;
    a=p/(h*h)-q/(2*h);
    b=-2*p/(h*h)+r;
    g=p/(h*h) + q/(2*h);
    A(i,i-1)=a;
    A(i,i)=b;
    A(i,i+1)=g;
    B(i,1)=s;
    i=c-1;
    p=1;
    q=-(x(i+1)+3)/(x(i+1)+1);
    r=(x(i+1)+3)/((x(i+1)+1)*(x(i+1)+1));
    s=2*(x(i+1)+1)+3*r;
    a=p/(h*h)-q/(2*h);
    b=-2*p/(h*h)+r;
    g=p/(h*h) + q/(2*h);
    A(i,i-1)=a+g;
    A(i,i)=b;
    B(i,1)=s;
    mat=[];
    mat(1,1)=0;
    mat(c-1,3)=0;
    for i=1:c-1
      if i==1
          mat(i,2)=A(i,i);
          mat(i,3)=A(i,i+1);
          mat(i,4)=B(i,1);
      elseif i<=c-2
          mat(i,1)=A(i,i-1);
          mat(i,2)=A(i,i);
          mat(i,3)=A(i,i+1);
          mat(i,4)=B(i,1);
      elseif i==c-1
         mat(i,1)= A(i,i-1);
         mat(i,2)=A(i,i);
         mat(i,4)=B(i,1);
      end
    end

    y=[];
    x=x(1:l);
    [y]=thomas(mat);
    y=[5 y];
    x
    y

    out = input('Name of Output File: ','s');
    fout = fopen(out,'w');
    fprintf(fout,'%s\n','x');
    fprintf(fout,'%f ',x);
    fprintf(fout,'\n');
    fprintf(fout,'%s\n','y');
    fprintf(fout,'%f ',y);

    fclose(fout);
    y=y';
    scatter(x,y,'filled');
 end

    
 function [A,B,c] = matrix(h,c,x,A,B)


    for i=1:c-3
    p=1;
    q=-(x(i+1)+3)/(x(i+1)+1);
    r=(x(i+1)+3)/((x(i+1)+1)*(x(i+1)+1));
    s=2*(x(i+1)+1)+3*r;
    a=p/(h*h)-q/(2*h);
    b=-2*p/(h*h)+r;
    g=p/(h*h) + q/(2*h);
    if i==1
    A(i,1)=b;
    A(i,2)=g;
    B(i,1)=s-5*a;
    elseif(i<=c-3)
    A(i,i-1)=a;
    A(i,i)=b;
    A(i,i+1)=g;
    B(i,1)=s;
    end       
    end
    end

    function [x]=thomas(A)
    alpha=[];
    beta=[];
    x=[];
    alpha(1)=A(1,2);
    beta(1)=A(1,4);
    n=length(A(:,4));
    for i=2:n
        alpha(i)=A(i,2)-(A(i,1)/alpha(i-1))*A(i-1,3);
        beta(i)=A(i,4)-(A(i,1)/alpha(i-1))*beta(i-1);
    end
    x(n)=beta(n)/alpha(n);
    for i=n-1:-1:1
        x(i)=(beta(i)-A(i,3)*x(i+1))/alpha(i);
    end
    end


